import threading


node_want_to_terminate: threading.Event = threading.Event()
